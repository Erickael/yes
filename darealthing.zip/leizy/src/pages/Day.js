import React, { useState } from "react";
import CheckboxGroup from "./CheckboxGroup";

const Day = () => {
  const [checkedPart, setCheckedPart] = useState([false, false, false, false]);
  const [checkedFull, setCheckedFull] = useState([false, false, false, false]);

  const handleCheckboxChange = (group, index, value) => {
    if (group === "Part") {
      const newCheckedPart = [...checkedPart];
      if (value) {
        // If a checkbox is being checked, ensure only 2 can be checked
        const checkedCount = newCheckedPart.filter((item) => item).length;
        if (checkedCount >= 2) {
          const firstCheckedIndex = newCheckedPart.findIndex((item) => item);
          newCheckedPart[firstCheckedIndex] = false;
        }
      }
      newCheckedPart[index] = value;
      setCheckedPart(newCheckedPart);
      if (value) {
        setCheckedFull([false, false, false, false]);
      }
    } else {
      const newCheckedFull = [false, false, false, false];
      newCheckedFull[index] = value;
      setCheckedFull(newCheckedFull);
      if (value) {
        setCheckedPart([false, false, false, false]);
      }
    }
  };

  return (
    <div>
      <CheckboxGroup
        group="Part"
        checkedItems={checkedPart}
        onCheckboxChange={handleCheckboxChange}
      />
      <CheckboxGroup
        group="Full"
        checkedItems={checkedFull}
        onCheckboxChange={handleCheckboxChange}
      />
    </div>
  );
};

export default Day;
