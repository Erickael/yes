import React from "react";

const CheckboxGroup = ({ group, checkedItems, onCheckboxChange }) => {
  const handleChange = (index) => (event) => {
    onCheckboxChange(group, index, event.target.checked);
  };

  return (
    <div>
      <h2>Component {group}</h2>
      {checkedItems.map((isChecked, index) => (
        <div key={index}>
          <input
            type="checkbox"
            checked={isChecked}
            onChange={handleChange(index)}
          />
        </div>
      ))}
    </div>
  );
};

export default CheckboxGroup;
