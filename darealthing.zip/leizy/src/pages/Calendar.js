﻿import React, { useState } from "react";
import "./Calendar.css";
import Day from "./Day";

export default function Calendar() {
  const days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];
  const times = ["Worked", "Remote", "Sick Leave", "Leave"];
  const [weekOffset, setWeekOffset] = useState(0);

  const getDate = (dayIndex) => {
    const today = new Date();
    today.setDate(today.getDate() + weekOffset * 7);
    const currentDay = today.getDay();
    const difference =
      dayIndex >= currentDay
        ? dayIndex - currentDay
        : 7 - (currentDay - dayIndex);
    const targetDate = new Date(today.setDate(today.getDate() + difference));
    return targetDate; // Return Date object
  };
  const getYear = () => {
    const today = new Date();
    today.setDate(today.getDate() + weekOffset * 7);
    return today.getFullYear();
  };
  const getMonth = () => {
    const today = new Date();
    today.setDate(today.getDate() + weekOffset * 7);
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    return monthNames[today.getMonth()];
  };

  const isToday = (date) => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  return (
    <div>
      <div className="year">{getYear()}</div>
      <div className="month">{getMonth()}</div>
      <button onClick={() => setWeekOffset(weekOffset - 1)}>
        Previous Week
      </button>
      <button onClick={() => setWeekOffset(weekOffset + 1)}>Next Week</button>
      <button onClick={() => setWeekOffset(0)}>Current Week</button>
      <Day max="1"></Day>
    </div>
  );
}
