import React, { useState } from 'react';
import { Link, useMatch, useResolvedPath } from 'react-router-dom';
import logo from './images/logo.png';
import user from './images/user.png';
import profile from './images/profile.png';
import setting from './images/setting.png';
import logout from './images/logout.png';
export default function Navbar() {
    const [isMenuActive, setMenuActive] = useState(false);

    const toggleMenu = () => {
        setMenuActive(!isMenuActive);
    };

    return (

        <nav className="nav">
            <img src={logo} alt="Logo" className="logo" />
            <ul >
                <li>
                    <CustomLink to="/Home">Home</CustomLink >
                </li>
                <li>
                    <CustomLink to="/About">About</CustomLink >
                </li>
                <li>
                    <CustomLink to="/Calendar">Calendar</CustomLink >
                </li>
            </ul>
            <img src={user} alt="user" className="user-pic-profile" onClick={toggleMenu} />
            <div className={`sub-menu-wrap ${isMenuActive ? 'active' : ''}`} id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src={user} alt="user" className="user" />
                        <h2>John Doe</h2>
                    </div>
                    <hr />
                    <Link to="/Profile" class="sub-menu-link">
                        <img src={profile} alt="profile" className="profile" />
                        <p>Edit Profile</p>
                        <span>{'>'}</span>
                    </Link>
                    <Link to="/Settings" class="sub-menu-link">
                        <img src={setting} alt="setting" className="setting" />
                        <p>Settings</p>
                        <span>{'>'}</span>
                    </Link>
                    <a href="/" class="sub-menu-link">
                        <img src={logout} alt="logout" className="logout" />
                        <p>Log out</p>
                        <span>{'>'}</span>
                    </a>
                </div>
            </div>
        </nav>

    );
}

function CustomLink({ to, children, ...props }) {
    const resolvedPath = useResolvedPath(to);
    const isActive = useMatch({ path: resolvedPath.pathname, end: true })
    return (
        <li className={isActive ? "active" : ""}>
            <Link to={to} {...props}>
                {children}
            </Link>
        </li>
    )
}