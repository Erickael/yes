import Navbar from "./navbar";
import About from "./pages/About";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import MyCalendar from "./pages/Calendar";

import { BrowserRouter, Route, Routes } from "react-router-dom";
function App() {
    return (
        <BrowserRouter>

            <Navbar />
            <div className="container">
                <Routes>
                    <Route path="/Home" element={<Home />} />
                    <Route path="/About" element={<About />} />
                    <Route path="/Calendar" element={<MyCalendar />} />
                    <Route path="/Profile" element={<Profile />} />
                    <Route path="/Settings" element={<Settings />} />
                </Routes>
            </div>
        </BrowserRouter>
    );
}

export default App;